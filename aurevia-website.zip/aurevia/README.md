# Aurevia (fictional demo)
Static HTML/CSS/JS site. Open index.html, or run `python3 -m http.server 8000` and visit http://localhost:8000.
Contact form is a demo (no backend). Images are inline SVG art placeholders: replace with licensed photos.
