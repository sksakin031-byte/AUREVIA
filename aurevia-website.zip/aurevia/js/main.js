const $=(s)=>[...document.querySelectorAll(s)];
addEventListener('load',()=>setTimeout(()=>$('#ld').forEach(e=>e.classList.add('h')),250));
const b=$('.burger')[0],u=$('.nav ul')[0];b.onclick=()=>b.setAttribute('aria-expanded',u.classList.toggle('open'));
$('.nav a').forEach(a=>a.onclick=()=>u.classList.remove('open'));
const io=new IntersectionObserver(e=>e.forEach(x=>{if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}}),{threshold:.1});$('.rv').forEach(e=>io.observe(e));
const t=$('#top')[0];addEventListener('scroll',()=>t.classList.toggle('show',scrollY>500));t.onclick=()=>scrollTo({top:0,behavior:'smooth'});
$('.filters button').forEach(f=>f.onclick=()=>{$('.filters button').forEach(x=>x.classList.remove('on'));f.classList.add('on');$('[data-c]').forEach(c=>c.hidden=f.dataset.f!='All'&&c.dataset.c!=f.dataset.f)});
$('.acc button').forEach(q=>q.onclick=()=>{const a=q.nextElementSibling,o=q.getAttribute('aria-expanded')=='true';q.setAttribute('aria-expanded',!o);a.style.maxHeight=o?0:a.scrollHeight+'px';q.lastElementChild.textContent=o?'+':'\u2212'});
const f=$('#cf')[0];if(f)f.onsubmit=e=>{e.preventDefault();const v=i=>document.getElementById(i).value.trim(),E={};
if(v('name').length<2)E.name='Enter your name.';if(!/^\S+@\S+\.\S+$/.test(v('email')))E.email='Enter a valid email address.';
if(v('phone')&&!/^[+\d][\d\s()-]{6,}$/.test(v('phone')))E.phone='Enter a valid phone number or leave it blank.';
if(!v('service'))E.service='Choose a service.';if(!v('budget'))E.budget='Choose a budget.';if(v('message').length<10)E.message='Write at least 10 characters.';
['name','email','phone','service','budget','message'].forEach(k=>document.getElementById('e-'+k).textContent=E[k]||'');
const n=document.getElementById('note');n.className='on';const bad=Object.keys(E);
if(bad.length){n.textContent='Please fix the highlighted fields.';document.getElementById(bad[0]).focus()}
else{n.textContent='Demo only: your form is valid, but nothing was sent because this site has no backend.';f.reset()}};
